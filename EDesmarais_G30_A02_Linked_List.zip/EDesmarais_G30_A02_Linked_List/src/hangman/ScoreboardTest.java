package hangman;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * @author Emylie-Rose Desmarais
 * <p>Title: ScoreboardTest</p>
 * <p>Description: this JUnit Test cases class is used to test the main methods of the Scoreboard class</p>
 * <p>Assignment: 02</p>
 * <p>Course: 420-G30</p>
 */
class ScoreboardTest {

	/**
	 * The default constructor should not add any player and should set the number
	 * of players to 0.
	 */
	@Test
	void testcase1() {
		Scoreboard score1 = new Scoreboard();
		assertEquals(score1.getNumPlayers(), 0);
	}// testcase1

	/**
	 * The addPlayer method should add players to the doubly list of players.
	 * (boundary test)
	 */
	@Test
	void testcase2() {
		Scoreboard score2 = new Scoreboard();
		score2.addPlayer("Name");
		score2.addPlayer(null);
		assertEquals(score2.getNumPlayers(), 1);
	}// testcase2

	/**
	 * The gamePlayed method must increment a player’s games played and games won
	 * (if games won)
	 */
	@Test
	void testcase3() {
		Scoreboard score3 = new Scoreboard();
		score3.addPlayer("Marco");
		assertEquals(score3.gamePlayed("Marco", true).getNumGamesPlayed(), 1);
		assertNull(score3.gamePlayed("Shannon", true));
	}// testcase3

	/**
	 * The getNextPlayer must return the player at the index mentioned using an
	 * empty list, a list of 1 player, and a list of 3 players.
	 */
	@Test
	void testcase4() {
		Scoreboard score4 = new Scoreboard();
		assertNull(score4.getNextPlayer(0));  
		
		score4.addPlayer("Marco");
		assertEquals(score4.getNextPlayer(0).getName(), "Marco");
		assertNull(score4.getNextPlayer(1));
		
		score4.addPlayer("Polo");
		score4.addPlayer("Shannon");
		assertEquals(score4.getNextPlayer(2).getName(), "Marco");
		assertNull(score4.getNextPlayer(-1));
		assertNull(score4.getNextPlayer(3));
	}// testcase4

}// ScoreboardTest
