package hangman;

import java.awt.Dimension;
import java.awt.Font;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.JComboBox;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.FocusListener;
import java.io.File;
import java.awt.event.ActionEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.Color;
import java.awt.SystemColor;

/**
 * @author Emylie-Rose Desmarais (2146356)
 *         <p>
 *         Title: PlayerPanel
 *         </p>
 *         <p>
 *         Description: this JPanel class is a user interface used for the user
 *         to input their username.
 *         </p>
 *         <p>
 *         Assignment: A02
 *         </p>
 *         <p>
 *         Course: 420-G30
 *         </p>
 */
public class PlayerPanel extends JPanel {

//	private Scoreboard score = new Scoreboard();
	public String playerName = "Oupsies";
	private JTextField textField;
	Scoreboard score;

	/**
	 * Create the panel.
	 */
	public PlayerPanel(Scoreboard s) {

		if (new File("saveScore.ser").isFile())
			score = Scoreboard.deserialize();
		else
			score = new Scoreboard();
		System.out.println("Scoreboard Deserialized when clicked in the Playerpanel");
		System.out.println("num in constructor: " + score.getNumPlayers());

		setPreferredSize(new Dimension(688, 451));
		setLayout(null);

		JLabel lblNewLabel = new JLabel("WHAT IS YOUR NAME?");
		lblNewLabel.setBounds(97, 11, 506, 47);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 45));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		add(lblNewLabel);

		JComboBox comboBox = new JComboBox();
		comboBox.setForeground(Color.BLACK);
		comboBox.setBounds(234, 170, 223, 34);
		comboBox.setEnabled(false);
		comboBox.addItem("Already played");
		if (score != null)
			for (int i = 0; i < score.getNumPlayers(); i++) {
				comboBox.addItem(score.getNextPlayer(i).getName());
			} // for
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (comboBox.getSelectedIndex() != 0)
					setPlayerName(comboBox.getSelectedItem().toString());
			}
		});
		add(comboBox);

		textField = new JTextField();

		textField.setBounds(234, 264, 223, 34);
		textField.setEnabled(false);
		add(textField);
		textField.setColumns(10);

		JButton btnNewPlayer = new JButton("New Player");
		btnNewPlayer.setBackground(new Color(240, 240, 240));
		btnNewPlayer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == btnNewPlayer) {
					textField.setEnabled(true);
					comboBox.setEnabled(false);
//					setPlayerName(textField.getText().toString());
				} // if
			}// actionPerformed(ActionEvent)
		});
		btnNewPlayer.setBounds(289, 219, 110, 34);
		add(btnNewPlayer);

		JButton btnOldPlayer = new JButton("Old Player");
		btnOldPlayer.setBackground(new Color(240, 240, 240));
		btnOldPlayer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == btnOldPlayer) {
					textField.setEnabled(false);
					comboBox.setEnabled(true);
//					setPlayerName(comboBox.getSelectedItem().toString());
				} // if
			}
		});

		btnOldPlayer.setBounds(289, 125, 110, 34);
		add(btnOldPlayer);

		JButton btnStart = new JButton("Start Game");
		btnStart.setForeground(Color.WHITE);
		btnStart.setBackground(new Color(79, 135, 151));
		btnStart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (!textField.getText().toString().isEmpty()) {
					setPlayerName(textField.getText().toString());
					score.addPlayer(textField.getText().toString());
					score.serialize();
//					System.out.println("Input from the textfield : " + textField.getText().toString());
				} else if (comboBox.getSelectedIndex() != 0) {
					setPlayerName(comboBox.getSelectedItem().toString());
					System.out.println(comboBox.getSelectedItem().toString());
				}
				if (comboBox.getSelectedIndex() == 0) {
					
				}
			}
		});
		btnStart.setBounds(289, 325, 110, 36);
		add(btnStart);

		JLabel lblIMG = new JLabel(new ImageIcon("background.jpg"));
		lblIMG.setBounds(31, 69, 626, 382);
		add(lblIMG);
	}// PlayerPanel()

	public void setPlayerName(String n) {
		playerName = n;
	}// setPlayerName(String)

	public String getPlayerName() {
		System.out.println("Name from the player panel getPlayerName(): " + playerName);
		return playerName;
	}// getPlayerName()
}// PlayerPanel Panel
