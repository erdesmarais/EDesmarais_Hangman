package hangman;

import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import java.awt.Dimension;
import java.awt.Font;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 * @author Emylie-Rose Desmarais (2146356)
 * <p>Title: ScoreboardPanel</p>
 * <p>Description: this JPanel is used to display the scoreboard to the users</p>
 * <p>Assignment: 02</p>
 * <p>Course: 420-G30</p>
 */
public class ScoreBoardPanel extends JPanel {
	
	private Scoreboard score;
	/**
	 * Create the panel.
	 */
	public ScoreBoardPanel(Scoreboard s) {

		if (new File("saveScore.ser").isFile())
			score = Scoreboard.deserialize();
		else
			score = new Scoreboard();
			
		setLayout(null);
		setPreferredSize(new Dimension(688, 451));

		JTextArea textArea = new JTextArea();
		textArea.setBounds(30, 65, 619, 356);
		textArea.setEditable(false);
		add(textArea);
		textArea.setText(String.format("%30s%-20s%40s%40s\n%18s", " ", "Name", "Games Played", "Games Won", " "));
		for (int i = 0; i < 120; i++) {
			textArea.append("-");
		}
		textArea.append("\n");
		displayAllPlayers(textArea, score.getNumPlayers(), score);
		JLabel lblNewLabel = new JLabel("SCOREBOARD");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 45));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(159, 11, 337, 47);
		add(lblNewLabel);
	}// ScoreBoardPanel()
	
	private void displayAllPlayers(JTextArea textArea, int numPlayers, Scoreboard score) {
		score.sort();
		for (int i = 0; i < score.getNumPlayers(); i++) {
			Player currPlayer = score.getNextPlayer(i);
			textArea.append(String.format("%-30s%-50s%-50s%-50s\n", " ", currPlayer.getName(), currPlayer.getNumGamesPlayed(), currPlayer.getNumGamesWon()));
		}
	}// displayAllPlayers(JTextArea)
	
}// ScoreBoardPanel JPanel
