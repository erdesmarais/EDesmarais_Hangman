package hangman;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * @author Emylie-Rose Desmarais (2146356)
 * <p>Title: DictionaryTest</p>
 * <p>Description: This JUnit Test cases class is used to test the main methods of the Dictionary class</p>
 * <p>Assignment: A02</p>
 * <p>Course: 420-G30</p>
 */
class DictionaryTest {
	
	/**
	 * The words must fit the length requirements. 
	 */
	@Test
	void testcase1() {
		Dictionary dicti = new Dictionary();
		assertTrue(dicti.validateWord("Alaska"));
		assertTrue(dicti.validateWord("accomplishments"));
		assertTrue(dicti.validateWord("truthful"));
		
		assertFalse(dicti.validateWord("hey"));
		assertFalse(dicti.validateWord("overcompensation"));
	}//testcase1()
	
	/**
	 * The words must only contain letters (guessable characters).
	 */
	@Test
	void testcase2() {
		Dictionary dicti2 = new Dictionary();
		assertTrue(dicti2.validateWord("Alaska"));
		assertFalse(dicti2.validateWord("two words"));
		assertFalse(dicti2.validateWord("YouGot93"));
		assertFalse(dicti2.validateWord("YouGot$two"));
	}//testcase1()
	
	/**
	 * The readInList’s parameter  must be the word bank file location. 
	 */
	@Test
	void testcase3() {
		Dictionary dicti3 = new Dictionary();
		assertTrue(dicti3.readInList("word_db.txt"));
		assertFalse(dicti3.readInList("worddb.txt"));
	}//testcase3()

}//DictionaryTest
