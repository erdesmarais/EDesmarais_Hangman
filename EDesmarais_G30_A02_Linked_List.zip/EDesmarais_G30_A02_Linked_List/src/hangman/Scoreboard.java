/**
 * 
 */
package hangman;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import linked_data_structures.*;

/**
 * @author Emylie-Rose Desmarais (2146356)
 *         <p>
 *         Title: Scoreboard
 *         </p>
 *         <p>
 *         Description: this class is used to store all the users who have
 *         played at least a game, and all the functionalities to display and
 *         update the list of players.
 *         </p>
 *         <p>
 *         Assignment: 02
 *         </p>
 *         <p>
 *         Course: 420-G30
 *         </p>
 */
public class Scoreboard implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1057471072823133520L;
	public DoublyLinkedList<Player> players = new DoublyLinkedList<Player>();
	public int numPlayers = 0;

	public Scoreboard() {
		numPlayers = 0;
	}// Scoreboard()

	public void addPlayer(String n) {
		if (n != null) {
				players.add(new Player(n, 1, 0));
				numPlayers++;
				System.out.println("NumPlayers: " + numPlayers);
		}//if not null
	}// addPlayer()

	public void sort() {
		if (numPlayers > 1)
			for (int o = 0; o < numPlayers; o++) 
				for (int i = 0; i < numPlayers; i++) {
					Player player1 = players.getElementAt(o);
					Player player2 = players.getElementAt(i);
					if (player1.getName().compareToIgnoreCase(player2.getName()) < 0) {
						Player temp = player1;
						players.add(player2, o);
						players.remove(o+1);
						players.add(temp, i);
						players.remove(i+1);		
					}//if		
				}//for
	}// sort()

	public void setNumPlayers(int p) {
		numPlayers = p;
	}// setNumPlayers(int)

	public int getNumPlayers() {
		return numPlayers;
	}// getNumPlayers()

	public Player gamePlayed(String n, boolean winOrLose) {
		boolean found = false;
		Player foundPlayer = null;
		for (int i = 0; i < players.getLength() && !found; i++) {
			if (players.getElementAt(i).getName().equalsIgnoreCase(n)) {
				found = true;
				foundPlayer = players.getElementAt(i);
				if (winOrLose) {
					foundPlayer.setNumGamesWon(foundPlayer.getNumGamesWon() + 1);
				} // if winOrLose = true (player has won a new game)
			} // if
		} // for
		return foundPlayer;
	}// gamePlayed(String, boolean)

	public Player getNextPlayer(int index) {
		try {
			return players.getElementAt(index);
		} catch (IndexOutOfBoundsException e) {
			return null;
		} // catch
	}// getNextPlayer(int)

	public void serialize() {
		FileOutputStream file;
		ObjectOutputStream out;
		try {
			file = new FileOutputStream("saveScore.ser");
			out = new ObjectOutputStream(file);
			out.writeObject(this);
			out.close();
			System.out.println("The board has been serialized");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}// serialize()

	public static Scoreboard deserialize() {
		Scoreboard s;
		FileInputStream file;
		ObjectInputStream in;
		try {
			file = new FileInputStream("saveScore.ser");
			in = new ObjectInputStream(file);
			s = (Scoreboard) in.readObject();
			in.close();
			file.close();
			System.out.println("Deserialized");
			return s;
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} catch (IOException e1) {
			e1.printStackTrace();
			return null;
		} catch (ClassNotFoundException e2) {
			e2.printStackTrace();
			return null;
		}
	}// deserialize()

}// Scoreboard class
