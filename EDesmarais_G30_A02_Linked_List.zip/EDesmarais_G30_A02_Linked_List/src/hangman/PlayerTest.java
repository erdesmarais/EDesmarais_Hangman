package hangman;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * @author Emylie-Rose Desmarais (2146356)
 * <p>Title: PlayerTest </p>
 * <p>Description: this JUnit Test cases class is used to test the main methods in the Player class</p>
 * <p>Assignment: 02</p>
 * <p>Course: 420-G30</p>
 */
class PlayerTest {

	/**
	 * Constructor must set numGamesPlayed and numGamesWon to defaults and name to
	 * its value using correct values.
	 */
	@Test
	void testcase1() {
		Player player1 = new Player("Marco");
		assertEquals(player1.getName(), "Marco");
		assertEquals(player1.getNumGamesPlayed(), 0);
		assertEquals(player1.getNumGamesWon(), 0);
	}// testcase1()

	/**
	 * If incremented, numGamesPlayed should return the correct value.
	 */
	@Test
	void testcase2() {
		Player player2 = new Player("Marco");
		player2.setNumGamesPlayed(player2.getNumGamesPlayed() +1 );
		assertEquals(player2.getNumGamesPlayed(), 1);
	}// testcase2()

	/**
	 * If incremented, numGamesWon should return the correct value.
	 */
	@Test
	void testcase3() {
		Player player3 = new Player("Marco");
		player3.setNumGamesPlayed(player3.getNumGamesPlayed() +1 );
		player3.setNumGamesWon(player3.getNumGamesWon() +1 );
		assertEquals(player3.getNumGamesWon(), 1);
	}// testcase3()

}// PlayerTest JUnit
