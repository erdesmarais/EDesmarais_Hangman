/**
 * 
 */
package hangman;

import linked_data_structures.*;
import java.io.Serializable;
import java.util.ArrayList;

/**
 * @author Emylie-Rose Desmarais (2146356)
 * <p>Title: Hangman_Game</p>
 * <p>Description: this class is used to handle the logic behind the Hangman game. </p>
 * <p>Assignment: A02</p>
 * <p>Course: 420-G30</p>
 */
public class Hangman_Game implements Serializable {


	/**
	 * 
	 */
	private static final long serialVersionUID = -4506601344016304386L;
	private SinglyLinkedList<String> letters = new SinglyLinkedList<String>();
	private SinglyLinkedList<String> lettersGuessed = new SinglyLinkedList<String>();
	public String word;
	public boolean hintGiven;
	public Scoreboard score;
	private ArrayList<String> wordToDisplayArr = new ArrayList<String>();

	public Hangman_Game() {
		word = null;
		hintGiven = false;
	}// Hangman_Game()

	public Hangman_Game(String w, Scoreboard s) {
		if (w != null)
			word = w;
		else
			word = null;
		addLettersToList(word);
		hintGiven = false;
		score = s;
	}// Hangman_Game(String)

	public void setWord(String w) {
		if (w != null)
			word = w;
		else
			word = "Unknown";
	}// setWord(String)

	public String getWord() {
		return word;
	}// getWord()

	public void addLettersToList(String w) {
		for (int i = w.length() - 1; i >= 0 ; i--) {
			letters.add(String.valueOf(w.charAt(i)));
		} // for 0 to word length
	}// addLettersToList()
	
	public int getNumLetters() {
		return letters.getLength();
	}//getNumLetters()

	public boolean isLetterInWord(String l, int i) {
		lettersGuessed.add(l);
		boolean inIt = false;
		if (l.equalsIgnoreCase(letters.getElementAt(i)))
			inIt = true;
		return inIt;
	}// isLetterInWord(String)
	
	public String getWordUpdated(char let) {
		String wordToDisplay = "";
		
		return " ";
	}

	public String giveHint() {
		String hint = null;
		if (hintGiven) {
			hint = null;
		}//if hintGiven
			
		else {
			boolean isIn = false;
			do {
				int randomIndex = (int) (Math.random() * (letters.getLength()-0));
				hint = letters.getElementAt(randomIndex);
				System.out.println("Hint: " + hint);
				for (int i =0; i < lettersGuessed.getLength(); i++) {
					if (hint.equalsIgnoreCase(lettersGuessed.getElementAt(i))) {
						isIn = true;
						randomIndex = (int) Math.random() * letters.getLength();
					} else {
						isIn = false;
					}
				}	
									
			}while (isIn);//while !isIn
		} // if the hint has not already been given
		hintGiven = true;
		return hint;
	}//giveHint()

	public String winOrLose(int numTries, int numGood) {
		String result = "Good";
		if (numTries >= 6) {
			result = "L";	
		}
			
		else if (numGood == word.length())
			result = "W";
		return result;
	}// winOrLose()

}// Hangman_Game class
