package hangman;

import linked_data_structures.*;
import java.util.*;
import java.io.*;

/**
 * @author Emylie-Rose Desmarais (2146356)
 * <p>Title: Dictionary</p>
 * <p>Description: this class is used to read in the words, put them in a singly list, and handle them. </p>
 * <p>Assignment: A02</p>
 * <p>Course: 420-G30</p>
 */

public class Dictionary {

	private SinglyLinkedList<String> wordsList = new SinglyLinkedList<String>();
	public int numWords;
	private String filename;
	
	public Dictionary() {
		numWords = 0;
		filename = "Unknown";
	}//Dictionary()
	
	public Dictionary(String fn) {
		numWords = 0;
		if (fn != null) filename = fn;
		else filename = "Unknown";
	}//Dictionary()
	
	/**
	 * source : https://codingface.com/how-to-check-string-contains-special-characters-in-java/
	 * I took inspiration from this web site to check for special characters. 
	 */
	public boolean validateWord(String w ) {
		boolean isValid = true;
		String specialChars = "!@#$%&*()'+,.-/:;<=>?[]^_`{|}";
		
		if (w.length() < 6 || w.length() > 15) isValid = false;
		
		for (int i = 0; i < w.length() && isValid; i++)
			if ((Character.isDigit(w.charAt(i))))
				isValid = false;	
		
		for (int q = 0; q < w.length() && isValid; q++) {
			String ch = Character.toString(w.charAt(q));
			if (specialChars.contains(ch)) {
				System.out.println("This " + ch + " is a special character");
				isValid = false;
			}
		}//if
		if (w.contains(" ")) isValid = false;
		
		return isValid;
	}//validateWord(String)
	
	public boolean readInList(String f) {
		boolean itWorked = true;
		Scanner reads;
		File file;
		String currWord = null;
		try {
			file = new File(f);
			reads = new Scanner(file);
			while (reads.hasNext()) {
				reads.useDelimiter("\r?\n");
				currWord = reads.next();
				if (validateWord(currWord)) {
					wordsList.add(currWord);
					numWords++;
				}//if valid word			
			}//while reads has next
		}catch (FileNotFoundException e) {
			itWorked = false;
		} catch (IOException e2) {
			itWorked = false;
		}
		return itWorked;
	}//readInList(String)
	
	public String chooseRandomWord() {
		String random = null;
		int randomNum =(int) (Math.random() * (numWords - 0));
		random = wordsList.getElementAt(randomNum);
		System.out.println("randomNum: " + randomNum + "\nRandom word: " + random + "\nnumWords: " + numWords);
		wordsList.remove(randomNum);
		numWords--;
		return random;
	}//chooseRandomWord()

}//Dictionary class
