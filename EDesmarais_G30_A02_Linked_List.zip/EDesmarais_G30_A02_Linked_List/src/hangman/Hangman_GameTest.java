package hangman;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * @author Emylie-Rose Desmarais (2146356)
 * <p>Title: Hangman_GameTest</p>
 * <p>Description: this JUnit Test cases class is used to test the main methods of the Hangman_Game class.</p>
 * <p>Assignment: A02</p>
 * <p>Course: 420-G30</p>
 */
class Hangman_GameTest {

	@Test
	void testcase1() {
		// The constructor must set the word to the value added.
		Hangman_Game game1 = new Hangman_Game();
		assertNull(game1.getWord());

		Hangman_Game game1_2 = new Hangman_Game("Alaska", new Scoreboard());
		assertEquals(game1_2.getWord(), "Alaska");
	}// testcase1()

	@Test
	void testcase2() {
		//The addLetter method adds each letter to a singly linked list.
		Hangman_Game game2 = new Hangman_Game("Alaska", new Scoreboard());
		assertEquals(game2.getNumLetters(), 6);
	}// testcase2()

	@Test
	void testcase3() {
		//The isLetterInWord must return if the letter is in the word at the index provided.
		Hangman_Game game3 = new Hangman_Game("Alaska", new Scoreboard());
		assertTrue(game3.isLetterInWord("l", 1));
		assertTrue(game3.isLetterInWord("L", 1));
		assertFalse(game3.isLetterInWord("l", 2));
		assertFalse(game3.isLetterInWord("h", 1));
	}// testcase3()

	@Test
	void testcase4() {
		//The isLetterInWord must only accept a single letter. 
		Hangman_Game game4 = new Hangman_Game("Alaska", new Scoreboard());
		assertTrue(game4.isLetterInWord("a", 0));
		assertFalse(game4.isLetterInWord("al", 0));
		assertFalse(game4.isLetterInWord("%", 0));
		assertFalse(game4.isLetterInWord("3", 0));
	}// testcase4()

}// Hangman_GameTest JUnit Tests
