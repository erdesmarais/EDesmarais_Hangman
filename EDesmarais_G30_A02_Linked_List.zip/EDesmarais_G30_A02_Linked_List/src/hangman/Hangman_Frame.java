package hangman;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;
import java.awt.*;
import javax.swing.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.SwingConstants;
import javax.swing.JMenuItem;
import javax.swing.JLabel;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

/**
 * @author Emylie-Rose Desmarais (2146356)
 * <p>Title: Hangman_Frame</p>
 * <p>Description: This JFrame is used as a GUI. It handles the user's interaction with the game.</p>
 * <p>Assignment: A02</p>
 * <p>Course: 420-G30</p>
 */

public class Hangman_Frame extends JFrame implements Serializable{


	private final Color transparent = new Color(0, true);
	char l = 'A';
	private Dictionary dic = new Dictionary();
	private Hangman_Game game;
	private Scoreboard score = null;
	private PlayerPanel playerName = null;
	private String wordToDisplay = "";
	private String name = "Unknown";
	private int numTries;
	private int numGood;
	private String hangmanIMG[] = { "./hangman0.png", "hangman1.png", "hangman2.png", "hangman3.png", "hangman4.png",
			"hangman5.png", "hangman6.png" };

	// JFrame components
	private JPanel contentPane;
	private JMenuBar menuBar;
	private JMenu mainMenu;
	private JMenuItem itemNewGame;
	private JMenuItem itemScoreboard;
	private JMenuItem itemHint;
	private JMenuItem itemQuitGame;
	private JMenuItem itemRules;
	private Panel btnPanel;
	private JButton btnLetter[][];
	private JTextArea areaWord;
	private JLabel lblIMG;
	private JLabel lblHangman;
//	private static Hangman_Frame frame = null;
	private ArrayList<String> wordToDisplayArr = new ArrayList<String>();
	static Hangman_Frame frame = new Hangman_Frame();

	int numPos = 0;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				} // catch
			}// run()
		});// EventQueue
	}// main(String[])

	public void scoreboard_actionPerformed() {
		score.deserialize();
		JOptionPane.showMessageDialog(this, new ScoreBoardPanel(score), "Scoreboard", JOptionPane.PLAIN_MESSAGE);
	}// scoreboard_actionPerformed()

	public void rules_actionPerformed() {
		JOptionPane.showMessageDialog(this, new RulesPanel(), "Rules", JOptionPane.PLAIN_MESSAGE);
	}// rules_actionPerformed()

	public void quitGame_actionPerformed() {
		FileOutputStream file;
		ObjectOutputStream out;
		try {
			file = new FileOutputStream("saveGamer.ser");
			out = new ObjectOutputStream(file);
			out.writeObject(game);
			out.close();
			System.out.println("The object has been serialized");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}finally {
			System.exit(0);
		}
	}// quitGame_actionPerformed()

	private void getHint_actionPerfomed() {
		String hint = game.giveHint();
		if (hint == null)
			JOptionPane.showMessageDialog(this, "Unfortunately, you have already used your hint", "Hint Already Used",
					JOptionPane.PLAIN_MESSAGE);
		else {
			wordToDisplay = wordToDisplay.substring(wordToDisplay.length());
			for (int i = 0; i < game.getWord().length(); i++) {
				if (game.isLetterInWord(hint, i)) {
					wordToDisplayArr.set(i, String.valueOf(hint.toUpperCase()) + " ");
					numGood++;
				}//if
			} // for - row
			for (int i = 0; i < wordToDisplayArr.size(); i++) {
				wordToDisplay += wordToDisplayArr.get(i);
			}
			areaWord.setText(wordToDisplay);
		} // else -- hint is not null
	}// getHint_actionPerfomed()

	public static Hangman_Game deserialize() {
		Hangman_Game game;
		FileInputStream file;
		ObjectInputStream in;
		try {
			file = new FileInputStream("saveGamer.ser");
			in = new ObjectInputStream(file);
			game = (Hangman_Game) in.readObject();
			in.close();
			file.close();
			System.out.println("Deserialized");
			return game;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return null;
		} catch (IOException e1) {
			e1.printStackTrace();
			return null;
		} catch (ClassNotFoundException e2) {
			e2.printStackTrace();
			return null;
		}
	}// deserialize()

	public void startGame() {
		if (new File("saveScore.ser").isFile()) {
			Scoreboard temp = new Scoreboard();
			score = temp.deserialize();
			System.out.println("Scoreboard Deserialized \nNumPlayers: " + score.getNumPlayers());
		} else {
			score = new Scoreboard();
		}
		System.out.println("num players in the frame con: " + score.getNumPlayers());
		playerName = new PlayerPanel(score);
		JOptionPane.showMessageDialog(this, playerName, "Player's Name", JOptionPane.PLAIN_MESSAGE);
		if (name.equalsIgnoreCase("Oupsies")) {
			while (name.equalsIgnoreCase("Oupsies")) {
				JOptionPane.showMessageDialog(this, playerName, "Player's Name", JOptionPane.PLAIN_MESSAGE);
				name = playerName.getPlayerName();
			} // while
		} // if
		otherStartGame(btnLetter);
	}// startGame()
	
	public void otherStartGame(JButton[][] btnLetter) {
		lblHangman.setIcon(new ImageIcon(hangmanIMG[0]));
		String rw = dic.chooseRandomWord();
		System.out.println("Random word: " + rw);
		game = new Hangman_Game(rw, score);
		wordToDisplay = "";
		wordToDisplayArr.clear();
		
		for (int i = 0; i < game.getWord().length(); i++) {
			if (game.getWord().charAt(i) != ' ') {
				wordToDisplayArr.add("_ ");
				wordToDisplay += "_ ";
			}
		} // for
		
		areaWord.setText(wordToDisplay);

		for (int row = 0; row < btnLetter.length; row++) {
			for (int col = 0; col < btnLetter[0].length; col++) {
				btnLetter[row][col].setForeground(Color.white);
			}
		}
		numTries = 0;
		numGood = 0;
	}//otherStartGame()

	public void endGame(int numTries, int numGood) {
		if (game.winOrLose(numTries, numGood) != null) {
			if (game.winOrLose(numTries, numGood).equalsIgnoreCase("W")) {
				int yesOrNo = JOptionPane.showConfirmDialog(this,
						"CONGRATULATIONS! You have won the game!" + "\nWould you like to try again?", "Game Won!",
						JOptionPane.YES_NO_OPTION);
				score.deserialize();
				score.gamePlayed(name, true);
				score.serialize();
				if (yesOrNo == JOptionPane.YES_OPTION) {
					otherStartGame(btnLetter);
				} else {
					System.exit(0);
					quitGame_actionPerformed();
				}
				score.gamePlayed(name, true);
			} else if (game.winOrLose(numTries, numGood).equalsIgnoreCase("L")) {
				int yesOrNo = JOptionPane.showConfirmDialog(this, "Unfortunately, you could not guess the word "
						+ game.getWord() + "\nWould you like to try again?", "Game lost", JOptionPane.YES_NO_OPTION);
				if (yesOrNo == JOptionPane.YES_OPTION) {
					otherStartGame(btnLetter);
				} else {
					System.exit(0);
					quitGame_actionPerformed();
				}//else

				score.gamePlayed(name, false);
			}//else if
		}//if not null
	}// endGame(int, int)

	/**
	 * Create the frame.
	 */
	public Hangman_Frame() {
		
		System.out.println("Reading in the list: " + String.valueOf(dic.readInList("word_db.txt")));
		
		numTries = 0;
		numGood = 0;

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 902, 689);

		menuBar = new JMenuBar();
		setJMenuBar(menuBar);

		mainMenu = new JMenu("Menu");
		mainMenu.setHorizontalAlignment(SwingConstants.CENTER);
		menuBar.add(mainMenu);

		itemNewGame = new JMenuItem("New Game");
		mainMenu.add(itemNewGame);
		itemNewGame.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				startGame();
			}
		});

		itemScoreboard = new JMenuItem("Scoreboard");
		itemScoreboard.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				scoreboard_actionPerformed();
			}
		});
		mainMenu.add(itemScoreboard);

		itemHint = new JMenuItem("Get a Hint");
		itemHint.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getHint_actionPerfomed();
			}
		});
		mainMenu.add(itemHint);

		itemQuitGame = new JMenuItem("Quit Game");
		itemQuitGame.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				quitGame_actionPerformed();
			}
		});
		mainMenu.add(itemQuitGame);

		itemRules = new JMenuItem("Rules");
		itemRules.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rules_actionPerformed();
			}
		});
		mainMenu.add(itemRules);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		btnPanel = new Panel();
		btnPanel.setBounds(10, 451, 868, 169);
		btnPanel.setLayout(new GridLayout(2, 13));
		btnPanel.setBackground(transparent);
		contentPane.add(btnPanel);

		l = 'A';
		btnLetter = new JButton[2][13];
		for (int row = 0; row < 2; row++) {
			for (int col = 0; col < 13; col++) {
				btnLetter[row][col] = new JButton();
				btnLetter[row][col].setText(String.valueOf(l));
				btnLetter[row][col].setFont(new Font("Tahoma", Font.PLAIN, 35));
				btnLetter[row][col].setForeground(new Color(255, 255, 255));
				btnLetter[row][col].setBackground(transparent);
				btnLetter[row][col].setOpaque(false);
				btnLetter[row][col].setContentAreaFilled(false);
				btnLetter[row][col].setBorderPainted(false);
				btnLetter[row][col].addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						char let = 'A';
						String w = game.getWord();
						wordToDisplay = "";
						for (int i = 0; i < w.length(); i++)
							wordToDisplay += "_ ";
						wordToDisplay = wordToDisplay.substring(game.getWord().length());
						for (int row = 0; row < 2; row++) {
							for (int col = 0; col < 13; col++) {
								if (e.getSource() == btnLetter[row][col]) {
									boolean isIn = false;
									for (int i = 0; i < game.getWord().length(); i++) {
										wordToDisplay = "";
										if (game.isLetterInWord(String.valueOf(let), i)) {
											isIn = true;
											wordToDisplayArr.set(i, String.valueOf(let) + " ");
											numGood++;
										} // if
										if (isIn) { 
											btnLetter[row][col].setForeground(new Color(124, 207, 165));} 
										else {btnLetter[row][col].setForeground(new Color(212, 123, 138));}
									} // for
									if (isIn) {
										for (int i = 0; i < wordToDisplayArr.size(); i++) {
											wordToDisplay += wordToDisplayArr.get(i);
										}
									}//if isIn
									if (!isIn) {
										numPos++;
										if (numPos == 6)
											numPos = 0;
										numTries++;
										lblHangman.setIcon(new ImageIcon(hangmanIMG[numPos]));
										for (int i = 0; i < wordToDisplayArr.size(); i++) {
											wordToDisplay += wordToDisplayArr.get(i);
										}
									}
								} // if
								let++;	
							} // for
						} // for
						areaWord.setText(wordToDisplay);
						endGame(numTries, numGood);
					}// actionPerformed(ActionEvent)
				});
				btnPanel.add(btnLetter[row][col]);
				l++;
			} // for - col
		} // for - rows

		areaWord = new JTextArea();
		areaWord.setBounds(51, 220, 547, 132);
		areaWord.setFont(new Font("Tahoma", Font.PLAIN, 60));
		areaWord.setForeground(new Color(255, 255, 255));
		areaWord.setOpaque(false);
		areaWord.setEditable(false);
		contentPane.add(areaWord);

		lblIMG = new JLabel(new ImageIcon("background.jpg"));
		lblIMG.setBounds(-21, -37, 927, 707);
		lblIMG.setOpaque(false);
		contentPane.add(lblIMG);

		lblHangman = new JLabel(new ImageIcon(hangmanIMG[0]));
		lblHangman.setBounds(559, 33, 289, 400);
		lblHangman.setOpaque(true);
		lblHangman.setBorder(BorderFactory.createMatteBorder(6, 6, 6, 6, Color.black));
		contentPane.add(lblHangman);
		contentPane.setComponentZOrder(lblHangman, 1);

		contentPane.setComponentZOrder(lblIMG, 2);
		contentPane.setComponentZOrder(btnPanel, 0);
		contentPane.setComponentZOrder(areaWord, 0);
		
		startGame();
		JOptionPane.showMessageDialog(this,
				"Unfortunately, as I have been feeling sick lately, I have not been able \nto complete the game serialization part. It will start a new game instead.\n\n Written on 2022/11/09", "No Game Serialization",
				JOptionPane.PLAIN_MESSAGE);
	}// Hangman_Frame()
	
}// Hangman_Frame JFrame class
