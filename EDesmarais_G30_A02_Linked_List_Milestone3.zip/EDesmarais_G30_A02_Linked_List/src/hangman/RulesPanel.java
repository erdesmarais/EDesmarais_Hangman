package hangman;

import java.awt.Dimension;
import java.awt.Font;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

/**
 * @author Emylie-Rose Desmarais (2146356)
 */
public class RulesPanel extends JPanel {

	/**
	 * Create the panel.
	 */
	public RulesPanel() {
		setLayout(null);
		setPreferredSize(new Dimension(688, 451));

		String padding = "\n    ";

		JTextArea textArea = new JTextArea();
		textArea.setBounds(30, 65, 619, 356);
		textArea.setEditable(false);
		textArea.setFont(new Font("Tahoma", Font.PLAIN, 15));
		add(textArea);
		textArea.append(padding + "1.  The Hangman game chooses a random word for the player to guess.");
		textArea.append(padding + "  -  Each guessable letter is displayed as \"_\"");
		textArea.append("\n" + padding + "2.  The player must guess one letter at a time." + padding
				+ "  -  If the letter is in the word, then all occurrences of that letter should be displayed "
				+ padding + "     to the player" + padding
				+ "  -  If the letter is not in the word, then the letter is added to the list of guessed " + padding
				+ "     letters for the player to see, and a mistake is recorded");
		textArea.append("\n" + padding + "3.  The player must guess the word before making 6 mistakes.");

		JLabel lblNewLabel = new JLabel("RULES");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 45));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(159, 11, 337, 47);
		add(lblNewLabel);
	}// RulesPanel()
}// RulesPanel()
