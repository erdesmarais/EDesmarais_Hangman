package hangman;

import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import java.awt.Dimension;
import java.awt.Font;

/**
 * @author Emylie-Rose Desmarais (2146356)
 */
public class ScoreBoardPanel extends JPanel {

//	private Scoreboard score = new Scoreboard();

	private void displayAllPlayers(JTextArea textArea, int numPlayers, Scoreboard score) {
		System.out.println(score.getNumPlayers());
		for (int i = 0; i < score.getNumPlayers(); i++) {
			Player currPlayer = score.getNextPlayer(i);
			System.out.println("displayallPlayers " + currPlayer.getName());
			textArea.append(String.format("%30s%-20s%40s%40s", " ", currPlayer.getName(), currPlayer.getNumGamesPlayed(), currPlayer.getNumGamesWon()));
		}
	}// displayAllPlayers(JTextArea)

	/**
	 * Create the panel.
	 */
	public ScoreBoardPanel(Scoreboard score) {
		setLayout(null);
		setPreferredSize(new Dimension(688, 451));

		JTextArea textArea = new JTextArea();
		textArea.setBounds(30, 65, 619, 356);
		textArea.setEditable(false);
		add(textArea);
		textArea.setText(String.format("%30s%-20s%40s%40s\n%18s", " ", "Name", "Games Played", "Games Won", " "));
		for (int i = 0; i < 120; i++) {
			textArea.append("-");
		}
		textArea.append("\n");
		displayAllPlayers(textArea, score.getNumPlayers(), score);

		JLabel lblNewLabel = new JLabel("SCOREBOARD");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 45));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(159, 11, 337, 47);
		add(lblNewLabel);

	}// ScoreBoardPanel()
}// ScoreBoardPanel JPanel
