/**
 * 
 */
package hangman;

/**
 * @author Emylie-Rose Desmarais (2146356)
 *
 */
public class Player {
	
	public String name;
	public int numGamesPlayed;
	public int numGamesWon;

	public Player() {
		name = "Unknown";
		numGamesPlayed = 0;
		numGamesWon = 0;
	}//Player()
	
	public Player(String n, int gp, int gw) {
		if (n != null) name = n;
		if (gp >= 0) numGamesPlayed = gp;
		if (gw >= 0 && gw <= gp) numGamesWon = gw; 
	}//Player(String, int, int)
	
	public void setName(String n) {
		if (n != null) name = n;
	}//setName(String)

	public void setNumGamesPlayed(int gp) {
		if (gp >= 0) numGamesPlayed = gp;
	}//setNumGamesPlayed(int)

	public void setNumGamesWon(int gw) {
		if (gw >= 0 && gw <= numGamesPlayed) numGamesWon = gw;
	}//setNumGamesWon(int)

	public String getName() {
		return name;
	}//getName()

	public int getNumGamesPlayed() {
		return numGamesPlayed;
	}//getNumGamesPlayed()

	public int getNumGamesWon() {
		return numGamesWon;
	}//getNumGamesWon()
		
}//Player class
