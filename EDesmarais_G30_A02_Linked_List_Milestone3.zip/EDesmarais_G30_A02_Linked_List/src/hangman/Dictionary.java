package hangman;

import linked_data_structures.*;
import java.util.*;
import java.io.*;

/**
 * @author Emylie-Rose Desmarais (2146356)
 */

public class Dictionary {

	private SinglyLinkedList<String> wordsList = new SinglyLinkedList<String>();
	public int numWords;
	private String filename;
	
	public Dictionary() {
		numWords = 0;
		filename = "Unknown";
	}//Dictionary()
	
	public Dictionary(String fn) {
		numWords = 0;
		if (fn != null) filename = fn;
		else filename = "Unknown";
	}//Dictionary()
	
	public boolean validateWord(String w ) {
		boolean isValid = true;
		
		return isValid;
	}//validateWord(String)
	
	public boolean readInList(String f) {
		boolean itWorked = true;
		Scanner reads;
		File file;
		String currWord = null;
		try {
			file = new File(f);
			reads = new Scanner(file);
			while (reads.hasNext()) {
				reads.useDelimiter("\r?\n");
				currWord = reads.next();
				if (validateWord(currWord)) {
					wordsList.add(currWord);
					numWords++;
				}//if valid word			
			}//while reads has next
		}catch (FileNotFoundException e) {
			itWorked = false;
		} catch (IOException e2) {
			itWorked = false;
		}
		return itWorked;
	}//readInList(String)
	
	public String chooseRandomWord() {
		String random = null;
		int randomNum = (int) Math.random() * numWords;
		random = wordsList.getElementAt(randomNum);
		return random;
	}//chooseRandomWord()

}//Dictionary class
