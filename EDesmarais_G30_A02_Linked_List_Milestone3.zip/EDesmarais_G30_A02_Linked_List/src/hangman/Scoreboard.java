/**
 * 
 */
package hangman;

import java.io.Serializable;
import linked_data_structures.*;

/**
 * @author Emylie-Rose Desmarais (2146356)
 *
 */
public class Scoreboard implements Serializable{

	public SinglyLinkedList<Player> players = new SinglyLinkedList<Player>();
	public static int numPlayers;
	
	public Scoreboard() {
		numPlayers = 0;
	}//Scoreboard()
	
	public void addPlayer(String n) {
		System.out.println("Name: " + n);
		players.add(new Player(n, 1, 0));
//		numPlayers++;
	}//addPlayer()
	
	public void setNumPlayers(int p) {
		numPlayers = p;
	}//setNumPlayers(int)
	
	public int getNumPlayers() {
		return numPlayers;
	}//getNumPlayers()
	
	public void gamePlayed(String n, boolean winOrLose) {
		boolean found = false;
		Player foundPlayer = null;
		for (int i = 0; i < players.getLength() && !found; i++) {
			if (players.getElementAt(i).getName().equalsIgnoreCase(n)) {
				found = true;
				foundPlayer = players.getElementAt(i);
				foundPlayer.setNumGamesPlayed(foundPlayer.getNumGamesPlayed() + 1);
				if (winOrLose) {
					foundPlayer.setNumGamesWon(foundPlayer.getNumGamesWon() + 1);
				}//if winOrLose = true (player has won a new game)
			}
		}//for
	}//gamePlayed(String, boolean)
	
	public Player getNextPlayer(int index) {
		players.getElementAt(index).getName();
		return players.getElementAt(index);
	}//getNextPlayer(int)

}//Scoreboard class
