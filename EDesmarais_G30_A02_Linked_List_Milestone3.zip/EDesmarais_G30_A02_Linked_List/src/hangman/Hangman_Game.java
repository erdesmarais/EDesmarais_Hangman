/**
 * 
 */
package hangman;

import linked_data_structures.*;
import java.io.Serializable;

/**
 * @author Emylie-Rose Desmarais (2146356)
 *
 */
public class Hangman_Game implements Serializable {

	private SinglyLinkedList<String> letters = new SinglyLinkedList<String>();
	private SinglyLinkedList<String> lettersGuessed = new SinglyLinkedList<String>();
	public String word;
	public boolean hintGiven;
	public Scoreboard score;

	public Hangman_Game() {
		word = null;
		addLettersToList(word);
		hintGiven = false;
	}// Hangman_Game()

	public Hangman_Game(String w, Scoreboard s) {
		if (w != null)
			word = w;
		else
			word = "Unknown";
		addLettersToList(word);
		hintGiven = false;
		score = s;
	}// Hangman_Game(String)

	public void setWord(String w) {
		if (w != null)
			word = w;
		else
			word = "Unknown";
	}// setWord(String)

	public String getWord() {
		return word;
	}// getWord()

	public int addLettersToList(String w) {
		for (int i = w.length() - 1; i >= 0 ; i--) {
			letters.add(String.valueOf(w.charAt(i)));
		} // for 0 to word length
		return letters.getLength();
	}// addLettersToList()

	public boolean isLetterInWord(String l, int i) {
		lettersGuessed.add(l);
		boolean inIt = false;
		if (l.equalsIgnoreCase(letters.getElementAt(i)))
			inIt = true;
		return inIt;
	}// isLetterInWord(String)

	public String giveHint() {
		String hint = null;
		if (hintGiven) {
			hint = null;
		}//if hintGiven
			
		else {
			boolean isIn = false;
			do {
				int randomIndex = (int) (Math.random() * (letters.getLength()-0));
				hint = letters.getElementAt(randomIndex);
				System.out.println("Hint: " + hint);
				for (int i =0; i < lettersGuessed.getLength(); i++) {
					if (hint.equalsIgnoreCase(lettersGuessed.getElementAt(i))) {
						isIn = true;
						randomIndex = (int) Math.random() * letters.getLength();
					} else {
						isIn = false;
					}
				}	
									
			}while (isIn);//while !isIn
		} // if the hint has not already been given
		hintGiven = true;
		return hint;
	}//giveHint()

	public String winOrLose(int numTries, int numGood) {
		String result = "Good";
		if (numTries >= 6) {
			result = "L";	
		}
			
		else if (numGood == word.length())
			result = "W";
		return result;
	}// winOrLose()

}// Hangman_Game class
